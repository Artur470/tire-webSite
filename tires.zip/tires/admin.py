from django.contrib import admin
from tires.models import (
    Tires,
    Category,


)

admin.site.register(Tires),
admin.site.register(Category),

