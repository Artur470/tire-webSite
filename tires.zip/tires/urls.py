from django.urls import path
from .views import (
    Tiresview,
    Categoryview,
)

urlpatterns = [
    path('category/<int:cat_id>', Categoryview.as_view()),
    path('list/<int:tir_id>/', Tiresview.as_view())

]




