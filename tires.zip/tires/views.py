from rest_framework import generics
from tires.serializers import (
    TiresSerializer,
    Categoryserializer,
)
from tires.models import (
    Tires,
    Category,
)




class Tiresview(generics.ListCreateAPIView):
    serializer_class = TiresSerializer
    queryset = Tires.objects.all()

    def get_queryset(self, *args, **kwargs):
        return Tires.objects.filter(id=self.kwargs["tir_id"])


class Categoryview(generics.ListCreateAPIView):
    queryset = Category.objects.all()
    serializer_class = Categoryserializer

    def get_queryset(self, *args, **kwargs):
        return Category.objects.filter(id=self.kwargs["cat_id"])
















