from django.db import models


class Width(models.Model):
    width = models.IntegerField()

    def __str__(self):
        return f"{self.width}"


class Profile(models.Model):
    profile = models.FloatField()

    def __str__(self):
        return f'{self.profile}'

class Diameter(models.Model):
    diameter = models.FloatField()

    def __str__(self):
        return f'{self.diameter}'


class CarType(models.Model):
    title = models.CharField(max_length=255)

    def __str__(self):
        return f'{self.title}'


class Seasonality(models.Model):
    title = models.CharField(max_length=255)

    def __str__(self):
        return f'{self.title}'


class Manufacturer(models.Model):
    title = models.CharField(max_length=255)

    def __str__(self):
        return f'{self.title}'


class SpeedIndex(models.Model):
    title = models.CharField(max_length=255)

    def __str__(self):
        return f'{self.title}'


class LoadIndex(models.Model):
    load = models.CharField(max_length=100)

    def __str__(self):
        return f'{self.load}'


class FuelEconomy(models.Model):
    category = models.CharField(max_length=255)

    def __str__(self):
        return f'{self.category}'


class GripOnWetSurfaces(models.Model):
    category = models.CharField(max_length=255)

    def __str__(self):
        return f'{self.category}'


class LoadIndexForDual(models.Model):
    dual = models.CharField(max_length=150)

    def __str__(self):
        return f'{self.dual}'


class Model(models.Model):
    model = models.CharField(max_length=200)

    def __str__(self):
        return f'{self.model}'


class ExternalNoiseLevel(models.Model):
    decibel = models.IntegerField()

    def __str__(self):
        return f'{self.decibel}'


class Category(models.Model):
    name = models.CharField(max_length=100)
    # slug = models.SlugField(max_length=100, unique=True, db_index=True)


    def __str__(self):
        return f'{self.name}'


class Tires(models.Model):
    category = models.ForeignKey('Category', on_delete=models.CASCADE)
    # slug = models.SlugField(max_length=100, unique=True, db_index=True)
    width = models.ForeignKey('width', on_delete=models.CASCADE)
    profile = models.ForeignKey('Profile', on_delete=models.CASCADE)
    diameter = models.ForeignKey('Diameter', on_delete=models.CASCADE)
    price = models.FloatField()
    car_type = models.ForeignKey('CarType', on_delete=models.CASCADE, null=True)
    seasonality = models.ForeignKey('Seasonality', on_delete=models.CASCADE, null=True)
    state = models.BooleanField(default=False)
    manufacturer = models.ForeignKey('Manufacturer', on_delete=models.PROTECT, null=True)
    discount = models.BooleanField(default=False)
    runflat = models.BooleanField(default=False)
    offroad = models.BooleanField(default=False)
    speed_index = models.ForeignKey('SpeedIndex', on_delete=models.CASCADE, null=True)
    load_index = models.ForeignKey('LoadIndex', on_delete=models.CASCADE, blank=True, null=True)
    fuel_economy = models.ForeignKey('FuelEconomy', on_delete=models.CASCADE, null=True)
    grip_on_wet_surfaces = models.ForeignKey('GripOnWetSurfaces', on_delete=models.CASCADE, null=True)
    external_noise_level = models.ForeignKey('ExternalNoiseLevel', on_delete=models.CASCADE, null=True)
    set = models.BooleanField()
    in_stock = models.BooleanField()
    model = models.ForeignKey('Model', on_delete=models.CASCADE)
    load_index_for_dual = models.ForeignKey('LoadIndexForDual', on_delete=models.CASCADE)



