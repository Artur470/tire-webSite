from rest_framework import serializers
from tires.models import (
    Tires,
    Category,
)

class TiresSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tires
        fields = '__all__'


class Categoryserializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = '__all__'